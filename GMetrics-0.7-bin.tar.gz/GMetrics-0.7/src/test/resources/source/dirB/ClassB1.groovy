package org.gmetrics.example

class ClassB1 {
    def method1() { }

    def method2() { }

    def closure3 = {





    }
}

