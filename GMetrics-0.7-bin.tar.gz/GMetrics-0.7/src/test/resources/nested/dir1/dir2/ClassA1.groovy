package dir1.dir2

class Examples {
}

