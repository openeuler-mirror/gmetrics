class ClassA2 {
    def method1() {
        println 'OK'

    }

    def method2() {


    }
}

