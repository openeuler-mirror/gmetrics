// Config script -- not a standalone class; For testing only

myConfig = {
    name = 'abc'    
}

def doConfig() {
    println "ok"
}