package org.gmetrics

class ClassA1 {
    def method1() {
        println 'OK'
    }

    def method2() {



    }
}

